$(function() {

  $("#frmCadastro").submit(function() {
    var ID = $("input#txtID").val();
    var nome = $("input#txtNome").val();
    var empresa = $("input#txtEmpresa").val();   
    createNewColaborador(ID,nome,empresa);
    
      
    return false;
  });

  var colaboradorCount = localStorage.getItem('colaboradorCount');  
  for (i=1;i<=colaboradorCount;i++)
    {
      var number = parseInt(i) + 1;
      var colaborador = jQuery.parseJSON(localStorage.getItem("colaborador_" + i));
      createMarkup(colaborador);
    } 
});


function createMarkup(colaborador) {
  $('ul#colaboradores').append(    
    "<li>" + 
      colaborador.ID + " " +
      colaborador.nome + " " +
      colaborador.empresa + " " +
    "</li>"
  );
}


function colaborador(ID,nome,empresa) {
  this.ID = ID;
  this.nome = nome;
  this.empresa = empresa;
  
}

function createNewColaborador(id,nome,empresa) {
  var createdColaborador = new colaborador(id,nome,empresa);
  if ( localStorage.colaboradorCount == undefined ) {
  localStorage.setItem('colaboradorCount', 0) 
  }
  var colaboradorSize = parseInt(localStorage.colaboradorCount) + 1;
  commitToStorage(colaboradorSize,createdColaborador);
}

function commitToStorage(objectCount,newObject) {
  // The unique key of the object:
  var item = 'colaborador_' + objectCount;
  localStorage.setItem('colaboradorCount', objectCount);
  
  // Put the object into storage
  localStorage.setItem(item, JSON.stringify(newObject));
  
  // Create Markup
  createMarkup(newObject);
}

// Paginação 

function Pager(listaColaboradores, itensPorPagina) {
this.listaColaboradores = listaColaboradores;
this.itensPorPagina = itensPorPagina;
this.currentPage = 1;
this.pages = 0;
this.inited = false;

this.showRecords = function(De, Para) {
var rows = document.getElementById(listaColaboradores).rows;
//FOR
for (var i = 1; i < rows.length; i++) {
if (i < De || i > Para)
rows[i].style.display = 'none';
else
rows[i].style.display = '';
}
}

this.showPage = function(paginaN) {
if (! this.inited) {
alert("not inited");
return;
}

var oldPageAnchor = document.getElementById('pg'+this.currentPage);
oldPageAnchor.className = 'pg-normal';

this.currentPage = paginaN;
var newPageAnchor = document.getElementById('pg'+this.currentPage);
newPageAnchor.className = 'pg-selected';

var De = (paginaN - 1) * itensPorPagina + 1;
var Para = De + itensPorPagina - 1;
this.showRecords(De, Para);
}

this.prev = function() {
if (this.currentPage > 1)
this.showPage(this.currentPage - 1);
}

this.next = function() {
if (this.currentPage < this.pages) {
this.showPage(this.currentPage + 1);
}
}

this.init = function() {
var rows = document.getElementById(listaColaboradores).rows;
var records = (rows.length - 1);
this.pages = Math.ceil(records / itensPorPagina);
this.inited = true;
}

this.showPageNav = function(listaColaboradores, positionId) {
if (! this.inited) {
alert("not inited");
return;
}
var element = document.getElementById(positionId);

var pagerHtml = '<span onclick="' + listaColaboradores + '.prev();"> &#171 </span>';
for (var page = 1; page <= this.pages; page++)
pagerHtml += '<span id="pg' + page + '" onclick="' + listaColaboradores + '.showPage(' + page + ');">' + page + '</span>';
pagerHtml += '<span onclick="'+listaColaboradores+'.next();"> »</span>';

element.innerHTML = pagerHtml;
}
}
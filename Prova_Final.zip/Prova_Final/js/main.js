
var list = [
    {"nome":"Jean Silva","empresa":"Bounge"},
    {"nome":"Marco Polo","empresa":"Leroy Merlin"},
    {"nome":"Juliana Mafia","empresa":"Casa da Sobremesa"}
];



                                                

function setList(list){
    var table = '<thead ></thead><tbody>';
    for(var key in list){
        table += '<tr><td style="color:#54A4E1">&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;'+ formatDesc(list[key].nome) +'</td><td width="250px">'+ formatDesc(list[key].empresa) +'</td><td width="100px"><a href="#frmCadastro" data-toggle="modal" id="teste"><img src="img/edit1.png" alt="" align="center" onclick="setUpdate('+key+');" >&nbsp;&nbsp;&nbsp;&nbsp;</a><img src="img/ico-del.png" onclick="deleteData('+key+');" ></td></tr>';
    }
    table += '</tbody>';
    document.getElementById("listTable").innerHTML = table;    
    saveListStorage(list);
}

function formatDesc(nome){
    var str = nome.toLowerCase();
    str = str.charAt(0).toUpperCase() + str.slice(1);
    return str;
}

function addData(){
   
    
    var nome = document.getElementById("nome").value;
    var empresa = document.getElementById("empresa").value;

    list.unshift({"nome":nome ,"empresa":empresa });
    setList(list);
    var pager = new Pager('listTable', 4);
                                    pager.init();
                                    pager.showPageNav('pager', 'pageNav');
                                    pager.showPage(1);
    resetForm();
}

function setUpdate(id){
    var obj = list[id];
	
    document.getElementById("nome").value = obj.nome;
    document.getElementById("empresa").value = obj.empresa;
    document.getElementById("btnUpdate").style.display = "inline-block";
    document.getElementById("btnAdd").style.display = "none";
    document.getElementById("inputIDUpdate").innerHTML = '<input id="idUpdate" type="hidden" value="'+id+'">';
    
}

function resetForm(){    
    document.getElementById("nome").value = "";
    document.getElementById("empresa").value = "";
    document.getElementById("btnUpdate").style.display = "none";
    document.getElementById("btnAdd").style.display = "inline-block";
    document.getElementById("inputIDUpdate").innerHTML = "";
    document.getElementById("errors").style.display = "none";
    
}

function updateData(){
    
    var id = document.getElementById("idUpdate").value;    
    var nome = document.getElementById("nome").value;
    var empresa = document.getElementById("empresa").value;

    list[id] = {"nome": nome, "empresa":empresa };
    setList(list);
	resetForm();
}

function deleteData(id){
    if(confirm("Realmente deseja apagar?")){
        if(id === list.length - 1){
            list.pop();
        }else if(id === 0){
            list.shift();
        }else{
            var arrAuxIni = list.slice(0,id);
            var arrAuxEnd = list.slice(id + 1);
            list = arrAuxIni.concat(arrAuxEnd);
        }
        setList(list);
    }
}

function deleteList(){
    if(confirm("Realmente deseja apagar tudo?")){
        list = [];
        setList(list);
    }
}

function saveListStorage(list){
    var jsonStr = JSON.stringify(list);
    localStorage.setItem("list",jsonStr);
}

function initListStorage(){
    var testList = localStorage.getItem("list");
    if(testList){
        list = JSON.parse(testList);
    }
    
    setList(list);   
    
}


initListStorage();

// Paginação 

function Pager(listaColaboradores, itensPorPagina) {
this.listaColaboradores = listaColaboradores;
this.itensPorPagina = itensPorPagina;
this.currentPage = 1;
this.pages = 0;
this.inited = false;

this.showRecords = function(De, Para) {
var rows = document.getElementById(listaColaboradores).rows;
//FOR
for (var i = 1; i < rows.length; i++) {
if (i < De || i > Para)
rows[i].style.display = 'none';
else
rows[i].style.display = '';
}
}

this.showPage = function(NumPagina) {
if (! this.inited) {
alert("Não possui dados");
return;
}

var oldPageAnchor = document.getElementById('pg'+this.currentPage);
oldPageAnchor.className = 'pg-normal';

this.currentPage = NumPagina;
var newPageAnchor = document.getElementById('pg'+this.currentPage);
newPageAnchor.className = 'pg-selected';

var De = (NumPagina - 1) * itensPorPagina + 1;
var Para = De + itensPorPagina - 1;
this.showRecords(De, Para);
}

this.prev = function() {
if (this.currentPage > 1)
this.showPage(this.currentPage - 1);
}

this.next = function() {
if (this.currentPage < this.pages) {
this.showPage(this.currentPage + 1);
}
}

this.init = function() {
var rows = document.getElementById(listaColaboradores).rows;
var records = (rows.length - 1);
this.pages = Math.ceil(records / itensPorPagina);
this.inited = true;
}

this.showPageNav = function(listaColaboradores, positionId) {
if (! this.inited) {
alert("Não iniciado");
return;
}
var element = document.getElementById(positionId);

var pagerHtml = '<span onclick="' + listaColaboradores + '.prev();" class="pg-normal"> < </span>';
for (var page = 1; page <= this.pages; page++)
pagerHtml += '<span id="pg' + page + '" onclick="' + listaColaboradores + '.showPage(' + page + ');" class="pg-normal">' + page + '</span>';
pagerHtml += '<span class="pg-normal" onclick="'+listaColaboradores+'.next();"> ></span>';

element.innerHTML = pagerHtml;
}
}

//troca de tabelas

function hide_all_tables(){
    document.getElementById('listTable').style.display='none';
    document.getElementById('table2').style.display='none';
    document.getElementById('table3').style.display='none';
    document.getElementById('table4').style.display='none';
    document.getElementById('table6').style.display='none';
}

function show_table(nome){
    document.getElementById(nome).style.display='block';
}


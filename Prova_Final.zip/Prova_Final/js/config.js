
function setConfig(){
    
    /*	
	    var texts = {
	        "title":"Controle de Produtos"
	    };
	    document.title = texts.title;
	    document.getElementById("navTitle").innerHTML = texts.title;
    */
    document.getElementById("navTitle").innerHTML = "Controle de Produtos";
}

setConfig();
